 $(document).ready(function(){
	/* var object1 = $('.onion');
	var object2 = $('.bowl');
	var object3 = $('.piece4');
	var object4 = $('.piece5')

	var layer = $('.layer');

	layer.mousemove(function(e){
		var valueX = (e.pageX * 1 / 30);
		var valueY = (e.pageY * 1 / 30);

		object1.css({
			'transform':'translate3d('+valueX+'px,'+valueY+'px,0) rotate(20deg)'
		});
	});

	layer.mousemove(function(e){
		var valueX = (e.pageX * -1 / 30);
		var valueY = (e.pageY * -1 / 30);

		object2.css({
			'transform':'translate3d('+valueX+'px,'+valueY+'px,0)'
		});
	});

	layer.mousemove(function(e){
		var valueX = (e.pageX * -1 / 30);
		var valueY = (e.pageY * -1 / 30);

		object3.css({
			'transform':'translate3d('+valueX+'px,'+valueY+'px,0) rotate(-20deg)'
		});
	});

	layer.mousemove(function(e){
		var valueX = (e.pageX * -1 / 30);
		var valueY = (e.pageY * -1 / 30);

		object4.css({
			'transform':'translate3d('+valueX+'px,'+valueY+'px,0) rotate(-20deg)'
		});
	});

	*/

	$(".counterup-text span").counterUp({
		delay: 1,
		time: 200
	});
});